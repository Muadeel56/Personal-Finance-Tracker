// icons.jsx — compact stroke icon set for WealthWise.
// <Icon name="dashboard" size={20} stroke={2} /> — inherits currentColor.
(function () {
  const P = {
    // nav
    dashboard: 'M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z',
    transactions: 'M7 7h13M7 7l3-3M7 7l3 3M17 17H4M17 17l-3-3M17 17l-3 3',
    budget: 'M3 12a9 9 0 1 0 9-9v9z M12 3v9l6.5 6.5',
    goals: 'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0-18 0 M12 12m-5 0a5 5 0 1 0 10 0a5 5 0 1 0-10 0 M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0-2 0',
    reports: 'M5 21V9M12 21V3M19 21v-7',
    categories: 'M4 4h7v7H4zM14 7l5-3 3 5-5 3zM4 15h7v6H4zM14 15h6v6h-6z',
    accounts: 'M3 7h18v12H3zM3 11h18M7 15h4',
    settings: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19.4 13a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V20a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7 18.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.7 7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H10a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V8a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z',
    // actions
    plus: 'M12 5v14M5 12h14',
    minus: 'M5 12h14',
    search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-3.5-3.5',
    calendar: 'M4 6h16v15H4zM4 10h16M8 3v4M16 3v4',
    filter: 'M3 5h18l-7 8v6l-4-2v-4z',
    chevDown: 'M5 9l7 7 7-7',
    chevUp: 'M5 15l7-7 7 7',
    chevLeft: 'M15 5l-7 7 7 7',
    chevRight: 'M9 5l7 7-7 7',
    more: 'M12 6h.01M12 12h.01M12 18h.01',
    moreH: 'M6 12h.01M12 12h.01M18 12h.01',
    arrowUp: 'M12 19V5M5 12l7-7 7 7',
    arrowDown: 'M12 5v14M5 12l7 7 7-7',
    arrowUpRight: 'M7 17L17 7M17 7H8M17 7v9',
    download: 'M12 3v12M7 10l5 5 5-5M5 21h14',
    edit: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4',
    trash: 'M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14',
    bell: 'M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
    logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
    sun: 'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
    moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z',
    check: 'M5 13l4 4L19 7',
    checkCircle: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8.5 12l2.5 2.5 4.5-5',
    x: 'M6 6l12 12M18 6L6 18',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    lock: 'M6 11h12v9H6zM8 11V7a4 4 0 1 1 8 0v4',
    mail: 'M3 5h18v14H3zM3 6l9 7 9-7',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM5 21a7 7 0 0 1 14 0',
    transfer: 'M4 8h13M14 5l3 3-3 3M20 16H7M10 13l-3 3 3 3',
    wallet: 'M3 7h15a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 7V6a2 2 0 0 1 2-2h11M17 13h.01',
    star: 'M12 3l2.6 5.7 6.4.6-4.8 4.3 1.4 6.4L12 17.3 6.4 20l1.4-6.4L3 9.3l6.4-.6z',
    shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
    sparkle: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z',
    globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.4 4 5.6 4 9s-1.5 6.6-4 9c-2.5-2.4-4-5.6-4-9s1.5-6.6 4-9z',
    flag: 'M5 21V4M5 4h13l-2.5 4L18 12H5',
    upload: 'M12 16V4M7 9l5-5 5 5M5 20h14',
    camera: 'M3 8h4l2-3h6l2 3h4v12H3zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
    info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5h.01',
    warn: 'M12 3l10 18H2zM12 9v5M12 17.5h.01',
    // category icons
    food: 'M4 3v7a3 3 0 0 0 6 0V3M7 3v18M17 3c-2 0-3 2-3 5s1 5 3 5m0 0v8',
    shopping: 'M6 8h12l1 12H5zM9 8V6a3 3 0 1 1 6 0v2',
    transport: 'M5 16V9l2-4h10l2 4v7M5 16h14M5 16v3H3v-3M19 16v3h2v-3M8 12h8M7 16h.01M17 16h.01',
    home: 'M4 11l8-7 8 7M6 9v11h12V9',
    entertainment: 'M4 5h16v14H4zM4 9h16M9 5L7 9M15 5l-2 4M10 13l4 2.5-4 2.5z',
    health: 'M12 20s-7-4.3-7-9.5A4 4 0 0 1 12 7a4 4 0 0 1 7 3.5C19 15.7 12 20 12 20z',
    salary: 'M4 7h16v12H4zM4 7V5h16v2M9 13a3 3 0 1 0 6 0 3 3 0 0 0-6 0',
    bills: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6',
    travel: 'M22 12l-9 2-3 6-2-1 1-5-5-1-2 2-2-1 4-4 9-2z',
    education: 'M12 4L2 9l10 5 10-5zM6 11v5c0 1 3 3 6 3s6-2 6-3v-5',
    coffee: 'M4 8h13v5a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4zM17 9h2a2 2 0 0 1 0 5h-2M7 3v2M11 3v2',
    pet: 'M5 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM19 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM9 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM15 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM12 12c-3 0-5 2.2-5 4.5 0 1.4 1.2 2 2.5 1.5 1.6-.6 3.4-.6 5 0 1.3.5 2.5-.1 2.5-1.5 0-2.3-2-4.5-5-4.5z',
    invest: 'M3 17l5-5 4 4 8-8M16 8h5v5',
    gift: 'M4 11h16v9H4zM2 7h20v4H2zM12 7v13M12 7S10 3 7.5 3 5 7 5 7M12 7s2-4 4.5-4S19 7 19 7',
  };

  function Icon({ name, size = 20, stroke = 1.8, fill = false, style = {}, className = '' }) {
    const d = P[name];
    if (!d) return null;
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" className={className}
        fill={fill ? 'currentColor' : 'none'} stroke={fill ? 'none' : 'currentColor'}
        strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>
        <path d={d} />
      </svg>
    );
  }

  window.Icon = Icon;
  window.ICON_NAMES = Object.keys(P);
})();
