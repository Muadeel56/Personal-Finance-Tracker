// data.jsx — sample data for WealthWise (persona: Maya Chen)
(function () {
  const cat = (name, color, icon) => ({ name, color, icon });
  const CATS = {
    food: cat('Food & Dining', 'var(--cat-rose)', 'food'),
    shopping: cat('Shopping', 'var(--cat-violet)', 'shopping'),
    transport: cat('Transport', 'var(--cat-sky)', 'transport'),
    housing: cat('Housing', 'var(--cat-indigo)', 'home'),
    fun: cat('Entertainment', 'var(--cat-amber)', 'entertainment'),
    health: cat('Health & Fitness', 'var(--cat-emerald)', 'health'),
    bills: cat('Bills & Utilities', 'var(--cat-teal)', 'bills'),
    travel: cat('Travel', 'var(--cat-indigo)', 'travel'),
    salary: cat('Income', 'var(--cat-emerald)', 'salary'),
  };

  const NAV = [
    ['Dashboard', 'dashboard'], ['Transactions', 'transactions'], ['Budget', 'budget'],
    ['Goals', 'goals'], ['Reports', 'reports'], ['Categories', 'categories'],
    ['Accounts', 'accounts'], ['Settings', 'settings'],
  ];

  const KPIS = {
    balance: { label: 'Total Balance', value: '$48,250.80', delta: '+2.4%', up: true,
      spark: [38, 40, 39, 43, 41, 45, 44, 47, 46, 48], color: 'var(--accent)' },
    income: { label: 'Monthly Income', value: '$8,400.00', delta: '+5.1%', up: true,
      spark: [6.8, 7.2, 7.0, 7.6, 7.4, 8.0, 8.4], color: 'var(--income)' },
    expenses: { label: 'Monthly Expenses', value: '$5,180.40', delta: '-3.2%', up: false,
      spark: [5.8, 5.6, 5.7, 5.4, 5.5, 5.3, 5.18], color: 'var(--expense)' },
    savings: { pct: 38, label: 'Savings Rate', sub: 'of income' },
  };

  const CASHFLOW = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    income: [7200, 7600, 7400, 8000, 8100, 8400],
    expense: [5600, 5200, 5800, 5100, 5400, 5180],
  };

  const SPENDING = [
    { label: 'Housing', value: 1850, color: 'var(--cat-indigo)' },
    { label: 'Food & Dining', value: 980, color: 'var(--cat-rose)' },
    { label: 'Transport', value: 620, color: 'var(--cat-sky)' },
    { label: 'Shopping', value: 540, color: 'var(--cat-violet)' },
    { label: 'Bills', value: 480, color: 'var(--cat-teal)' },
    { label: 'Other', value: 710, color: 'var(--cat-amber)' },
  ];

  const BUDGETS = [
    { cat: CATS.housing, spent: 1850, total: 2000 },
    { cat: CATS.food, spent: 980, total: 1000 },
    { cat: CATS.transport, spent: 620, total: 600 },
    { cat: CATS.shopping, spent: 540, total: 700 },
    { cat: CATS.fun, spent: 310, total: 400 },
    { cat: CATS.health, spent: 180, total: 300 },
    { cat: CATS.bills, spent: 480, total: 500 },
    { cat: CATS.travel, spent: 90, total: 800 },
  ];

  const TXNS = [
    { day: 'Today · Jun 4', items: [
      { t: 'Whole Foods Market', s: 'Groceries', cat: CATS.food, amt: -86.40, acct: 'Amex Gold' },
      { t: 'Salary — Acme Corp', s: 'Monthly payroll', cat: CATS.salary, amt: 4200.00, acct: 'Chase Checking' },
      { t: 'Uber', s: 'Ride to downtown', cat: CATS.transport, amt: -18.75, acct: 'Amex Gold' },
    ]},
    { day: 'Yesterday · Jun 3', items: [
      { t: 'Spotify Premium', s: 'Subscription', cat: CATS.fun, amt: -11.99, acct: 'Chase Checking' },
      { t: 'Equinox', s: 'Membership', cat: CATS.health, amt: -185.00, acct: 'Chase Checking' },
      { t: 'Blue Bottle Coffee', s: 'Coffee', cat: CATS.food, amt: -6.50, acct: 'Amex Gold' },
    ]},
    { day: 'Jun 2', items: [
      { t: 'Pacific Gas & Electric', s: 'Utilities', cat: CATS.bills, amt: -142.30, acct: 'Chase Checking' },
      { t: 'Amazon', s: 'Home supplies', cat: CATS.shopping, amt: -64.20, acct: 'Amex Gold' },
      { t: 'Freelance — Design', s: 'Side project', cat: CATS.salary, amt: 850.00, acct: 'Chase Checking' },
      { t: 'Shell', s: 'Fuel', cat: CATS.transport, amt: -52.10, acct: 'Amex Gold' },
    ]},
  ];

  const GOALS = [
    { name: 'Emergency Fund', icon: 'shield', cur: 12400, target: 20000, deadline: 'Dec 2026', color: 'var(--cat-emerald)', note: '6 months of expenses' },
    { name: 'Japan Trip', icon: 'travel', cur: 3200, target: 6000, deadline: 'Oct 2026', color: 'var(--cat-sky)', note: 'Tokyo & Kyoto, 2 weeks' },
    { name: 'New MacBook Pro', icon: 'invest', cur: 1850, target: 2500, deadline: 'Aug 2026', color: 'var(--cat-violet)', note: 'M-series, 16-inch' },
    { name: 'Home Down Payment', icon: 'home', cur: 28000, target: 80000, deadline: 'Jun 2028', color: 'var(--cat-indigo)', note: '20% on a 2BR condo' },
    { name: 'Wedding Fund', icon: 'gift', cur: 9500, target: 25000, deadline: 'Sep 2027', color: 'var(--cat-rose)', note: 'Venue + catering' },
  ];

  const CATEGORIES = [
    { cat: CATS.housing, count: 8, total: 1850 },
    { cat: CATS.food, count: 42, total: 980 },
    { cat: CATS.transport, count: 19, total: 620 },
    { cat: CATS.shopping, count: 14, total: 540 },
    { cat: CATS.fun, count: 11, total: 310 },
    { cat: CATS.health, count: 6, total: 380 },
    { cat: CATS.bills, count: 7, total: 480 },
    { cat: CATS.travel, count: 3, total: 290 },
  ];

  Object.assign(window, { WW_DATA: { CATS, NAV, KPIS, CASHFLOW, SPENDING, BUDGETS, TXNS, GOALS, CATEGORIES } });
})();
