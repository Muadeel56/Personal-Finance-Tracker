// ui.jsx — shared chrome + primitives for WealthWise
(function () {
  const { Icon } = window;

  // Theme wrapper sized to its artboard.
  function Frame({ theme = 'dark', children, style = {} }) {
    return (
      <div className="ww" data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', ...style }}>
        {children}
      </div>
    );
  }

  // colored category icon chip
  function CatIcon({ cat, size = 38, radius = 11, iconSize }) {
    return (
      <div className="cat-ic" style={{ width: size, height: size, borderRadius: radius, background: `color-mix(in srgb, ${cat.color} 16%, transparent)`, color: cat.color }}>
        <Icon name={cat.icon} size={iconSize || Math.round(size * 0.5)} stroke={1.9} />
      </div>
    );
  }

  function Logo({ size = 30, withWord = true, color }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
        <div style={{ width: size, height: size, borderRadius: size * 0.32, background: 'var(--accent-grad)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 14px var(--accent-glow)', flex: '0 0 auto' }}>
          <Icon name="sparkle" size={size * 0.62} stroke={0} fill={true} style={{ color: '#1A1206' }} />
        </div>
        {withWord && <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: size * 0.62, letterSpacing: '-0.03em', color: color || 'var(--text-primary)' }}>WealthWise</span>}
      </div>
    );
  }

  // Sidebar — full (240) or collapsed icon-rail (72)
  function Sidebar({ active = 'dashboard', collapsed = false, theme = 'dark' }) {
    const { NAV } = window.WW_DATA;
    const W = collapsed ? 72 : 240;
    return (
      <aside style={{ width: W, flex: `0 0 ${W}px`, height: '100%', background: 'var(--surface-1)', borderRight: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', padding: collapsed ? '22px 0' : '22px 18px' }}>
        <div style={{ padding: collapsed ? '0' : '0 6px', display: 'flex', justifyContent: 'center', marginBottom: 26 }}>
          <Logo size={30} withWord={!collapsed} />
        </div>

        {/* profile */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: collapsed ? 0 : '11px 10px', justifyContent: collapsed ? 'center' : 'flex-start', borderRadius: 12, background: collapsed ? 'none' : 'var(--surface-2)', marginBottom: 22 }}>
          <div className="avatar" style={{ width: 36, height: 36, fontSize: 14 }}>MC<span className="dot" /></div>
          {!collapsed && (
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, fontFamily: 'var(--font-display)', whiteSpace: 'nowrap' }}>Maya Chen</div>
              <span className="badge badge-amber" style={{ padding: '1px 7px', fontSize: 10, marginTop: 2 }}>
                <Icon name="star" size={9} fill={true} stroke={0} /> Premium
              </span>
            </div>
          )}
        </div>

        {/* nav */}
        <nav style={{ display: 'flex', flexDirection: 'column', gap: 3, flex: 1 }}>
          {!collapsed && <div className="t-label dim" style={{ padding: '0 12px 8px' }}>Menu</div>}
          {NAV.map(([label, icon]) => {
            const on = icon === active;
            return (
              <div key={icon} style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 12, height: 42, padding: collapsed ? 0 : '0 12px', justifyContent: collapsed ? 'center' : 'flex-start', borderRadius: 11, cursor: 'pointer', color: on ? 'var(--accent)' : 'var(--text-secondary)', background: on ? 'var(--accent-glow)' : 'transparent', fontWeight: on ? 600 : 500, fontSize: 14, fontFamily: 'var(--font-display)' }}>
                {on && <span style={{ position: 'absolute', left: 0, top: 9, bottom: 9, width: 3, borderRadius: 3, background: 'var(--accent)' }} />}
                <Icon name={icon} size={20} stroke={on ? 2.1 : 1.8} />
                {!collapsed && <span>{label}</span>}
              </div>
            );
          })}
        </nav>

        {/* bottom */}
        <div style={{ marginTop: 'auto', paddingTop: 14, borderTop: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <ThemeToggle theme={theme} collapsed={collapsed} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, height: 40, padding: collapsed ? 0 : '0 12px', justifyContent: collapsed ? 'center' : 'flex-start', borderRadius: 11, color: 'var(--text-secondary)', cursor: 'pointer', fontSize: 14, fontWeight: 500, fontFamily: 'var(--font-display)' }}>
            <Icon name="logout" size={19} /> {!collapsed && 'Log out'}
          </div>
        </div>
      </aside>
    );
  }

  function ThemeToggle({ theme = 'dark', collapsed }) {
    const dark = theme === 'dark';
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, height: 40, padding: collapsed ? 0 : '0 8px', justifyContent: collapsed ? 'center' : 'space-between', borderRadius: 11 }}>
        {!collapsed && <span style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-secondary)', fontSize: 14, fontWeight: 500, fontFamily: 'var(--font-display)' }}><Icon name={dark ? 'moon' : 'sun'} size={19} /> {dark ? 'Dark' : 'Light'}</span>}
        <div style={{ display: 'flex', background: 'var(--surface-3)', borderRadius: 999, padding: 3, gap: 2 }}>
          <div style={{ width: 26, height: 26, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', background: dark ? 'var(--accent)' : 'transparent', color: dark ? '#1A1206' : 'var(--text-muted)' }}><Icon name="moon" size={15} /></div>
          <div style={{ width: 26, height: 26, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', background: !dark ? 'var(--accent)' : 'transparent', color: !dark ? '#1A1206' : 'var(--text-muted)' }}><Icon name="sun" size={15} /></div>
        </div>
      </div>
    );
  }

  // Page top bar
  function TopBar({ title, subtitle, actions, search = true }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 26 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 className="t-h2" style={{ marginBottom: subtitle ? 4 : 0 }}>{title}</h1>
          {subtitle && <div className="t-body muted">{subtitle}</div>}
        </div>
        {search && (
          <div className="field" style={{ width: 240, height: 42 }}>
            <Icon name="search" size={17} style={{ color: 'var(--text-muted)' }} />
            <input placeholder="Search…" />
          </div>
        )}
        <button className="btn btn-icon btn-secondary" style={{ height: 42, width: 42, position: 'relative' }}>
          <Icon name="bell" size={18} />
          <span style={{ position: 'absolute', top: 9, right: 10, width: 7, height: 7, borderRadius: 999, background: 'var(--accent)', border: '2px solid var(--surface-1)' }} />
        </button>
        {actions}
        <div className="avatar" style={{ width: 42, height: 42, fontSize: 15 }}>MC<span className="dot" /></div>
      </div>
    );
  }

  // KPI stat card
  function StatCard({ data, accent, sparkColor }) {
    const { Sparkline } = window;
    return (
      <div className="card" style={{ padding: 20, position: 'relative', overflow: 'hidden', borderLeft: accent ? `3px solid ${accent}` : undefined }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
          <span className="t-label dim">{data.label}</span>
          <span className={`badge ${data.up ? 'badge-up' : 'badge-down'}`}>
            <Icon name={data.up ? 'arrowUp' : 'arrowDown'} size={11} stroke={2.4} />{data.delta}
          </span>
        </div>
        <div className="num" style={{ fontSize: 30, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 12 }}>{data.value}</div>
        <Sparkline data={data.spark} color={sparkColor || data.color} width={220} height={36} />
      </div>
    );
  }

  // status badge for budgets
  function StatusBadge({ pct }) {
    if (pct >= 100) return <span className="badge badge-down"><Icon name="warn" size={11} />Exceeded</span>;
    if (pct >= 80) return <span className="badge badge-amber"><Icon name="info" size={11} />Warning</span>;
    return <span className="badge badge-up"><Icon name="check" size={11} stroke={2.4} />On track</span>;
  }

  function money(n) {
    const neg = n < 0;
    return (neg ? '−' : '') + '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  Object.assign(window, { Frame, CatIcon, Logo, Sidebar, ThemeToggle, TopBar, StatCard, StatusBadge, money });
})();
