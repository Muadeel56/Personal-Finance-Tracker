// page-dashboard.jsx
(function () {
  const { Icon, Sidebar, TopBar, StatCard, CatIcon, StatusBadge, Ring, AreaLine, Donut, money } = window;

  function QuickAction({ icon, label, tint }) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, padding: '20px 8px', borderRadius: 14, background: 'var(--surface-2)', border: '1px solid var(--border-subtle)', cursor: 'pointer' }}>
        <div style={{ width: 46, height: 46, borderRadius: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', background: `color-mix(in srgb, ${tint} 16%, transparent)`, color: tint }}>
          <Icon name={icon} size={22} stroke={2} />
        </div>
        <span style={{ fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)' }}>{label}</span>
      </div>
    );
  }

  function BudgetRow({ b }) {
    const pct = Math.round((b.spent / b.total) * 100);
    const cls = pct >= 100 ? 'over' : pct >= 80 ? 'warn' : '';
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <CatIcon cat={b.cat} size={36} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7 }}>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>{b.cat.name}</span>
            <span className="num" style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>${b.spent.toLocaleString()} <span style={{ color: 'var(--text-muted)' }}>/ ${b.total.toLocaleString()}</span></span>
          </div>
          <div className="track"><div className={`fill ${cls}`} style={{ width: `${Math.min(pct, 100)}%` }} /></div>
        </div>
        <span className="num" style={{ fontSize: 12, width: 38, textAlign: 'right', color: cls === 'over' ? 'var(--expense)' : 'var(--text-muted)', fontWeight: 600 }}>{pct}%</span>
      </div>
    );
  }

  function TxnRow({ x }) {
    const inc = x.amt > 0;
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '11px 0', borderBottom: '1px solid var(--border-subtle)' }}>
        <CatIcon cat={x.cat} size={38} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{x.t}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{x.s}</div>
        </div>
        <span className="badge" style={{ background: `color-mix(in srgb, ${x.cat.color} 14%, transparent)`, color: x.cat.color, fontSize: 11 }}>{x.cat.name.split(' ')[0]}</span>
        <span className="num" style={{ fontSize: 13.5, fontWeight: 600, width: 92, textAlign: 'right', color: inc ? 'var(--income)' : 'var(--text-primary)' }}>{money(x.amt)}</span>
        <Icon name="moreH" size={16} style={{ color: 'var(--text-muted)', cursor: 'pointer' }} />
      </div>
    );
  }

  function GoalMini({ g }) {
    const pct = Math.round((g.cur / g.target) * 100);
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: 13, background: 'var(--surface-2)', border: '1px solid var(--border-subtle)' }}>
        <Ring pct={pct} size={56} stroke={6} color={g.color} track="var(--surface-3)" label={`${pct}%`} labelColor="var(--text-primary)" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 3 }}>{g.name}</div>
          <div className="num" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>${g.cur.toLocaleString()} <span style={{ color: 'var(--text-muted)' }}>/ ${g.target.toLocaleString()}</span></div>
        </div>
        <span className="badge badge-info" style={{ fontSize: 10.5 }}>{g.deadline}</span>
      </div>
    );
  }

  function Card({ title, action, children, style }) {
    return (
      <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column', ...style }}>
        {title && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
            <h3 className="t-h3" style={{ fontSize: 17 }}>{title}</h3>
            {action}
          </div>
        )}
        {children}
      </div>
    );
  }

  function RangeToggle() {
    const opts = ['1M', '3M', '6M', '1Y'];
    return (
      <div style={{ display: 'flex', gap: 2, background: 'var(--surface-2)', borderRadius: 9, padding: 3 }}>
        {opts.map((o, i) => (
          <span key={o} style={{ fontSize: 12, fontWeight: 600, padding: '5px 11px', borderRadius: 7, fontFamily: 'var(--font-mono)', background: o === '6M' ? 'var(--surface-3)' : 'transparent', color: o === '6M' ? 'var(--accent)' : 'var(--text-muted)', cursor: 'pointer' }}>{o}</span>
        ))}
      </div>
    );
  }

  function Dashboard() {
    const D = window.WW_DATA;
    return (
      <>
        <Sidebar active="dashboard" theme="dark" />
        <main style={{ flex: 1, minWidth: 0, height: '100%', overflow: 'hidden', padding: '30px 34px', background: 'var(--bg-base)' }}>
          <TopBar title="Welcome back, Maya" subtitle="Here's your financial overview for June 2026."
            actions={<button className="btn btn-primary"><Icon name="plus" size={17} stroke={2.4} />Add Transaction</button>} />

          {/* Zone A — KPIs */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 18, marginBottom: 18 }}>
            <StatCard data={D.KPIS.balance} sparkColor="var(--accent)" />
            <StatCard data={D.KPIS.income} accent="var(--income)" sparkColor="var(--income)" />
            <StatCard data={D.KPIS.expenses} accent="var(--expense)" sparkColor="var(--expense)" />
            <div className="card" style={{ padding: 20, display: 'flex', alignItems: 'center', gap: 18 }}>
              <Ring pct={38} size={92} stroke={9} color="var(--accent)" track="var(--surface-3)" label="38%" />
              <div>
                <div className="t-label dim" style={{ marginBottom: 8 }}>Savings Rate</div>
                <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5 }}>You're saving <strong style={{ color: 'var(--income)' }}>$3,220</strong> of your income this month.</div>
              </div>
            </div>
          </div>

          {/* Zone B — charts */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.85fr 1fr', gap: 18, marginBottom: 18 }}>
            <Card title="Cash Flow" action={<RangeToggle />}>
              <div style={{ display: 'flex', gap: 20, marginBottom: 6 }}>
                <Legend color="var(--income)" label="Income" val="$46,700" />
                <Legend color="var(--expense)" label="Expenses" val="$32,280" />
              </div>
              <AreaLine width={640} height={230}
                labels={D.CASHFLOW.labels}
                series={[{ color: 'var(--income)', data: D.CASHFLOW.income }, { color: 'var(--expense)', data: D.CASHFLOW.expense }]} />
            </Card>
            <Card title="Spending by Category">
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
                <Donut size={184} thickness={24} segments={D.SPENDING} center="$5,180" centerSub="this month" track="var(--surface-3)" />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 14px' }}>
                {D.SPENDING.map((s, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
                    <span style={{ width: 9, height: 9, borderRadius: 3, background: s.color, flex: '0 0 auto' }} />
                    <span style={{ color: 'var(--text-secondary)', flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.label}</span>
                    <span className="num" style={{ color: 'var(--text-primary)', fontWeight: 600 }}>${s.value}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Zone C — budget + quick actions */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 18, marginBottom: 18 }}>
            <Card title="Budget Overview" action={<span style={{ fontSize: 12.5, color: 'var(--accent)', fontWeight: 600, cursor: 'pointer' }}>View all →</span>}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {D.BUDGETS.slice(0, 5).map((b, i) => <BudgetRow key={i} b={b} />)}
              </div>
            </Card>
            <Card title="Quick Actions">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, flex: 1 }}>
                <QuickAction icon="arrowDown" label="Add Income" tint="var(--income)" />
                <QuickAction icon="arrowUp" label="Add Expense" tint="var(--expense)" />
                <QuickAction icon="transfer" label="Transfer" tint="var(--info)" />
                <QuickAction icon="goals" label="New Goal" tint="var(--accent)" />
              </div>
            </Card>
          </div>

          {/* Zone D — transactions + goals */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 18 }}>
            <Card title="Recent Transactions" action={<span style={{ fontSize: 12.5, color: 'var(--accent)', fontWeight: 600, cursor: 'pointer' }}>View all →</span>}>
              <div>
                {D.TXNS[0].items.concat(D.TXNS[1].items.slice(0, 2)).map((x, i) => <TxnRow key={i} x={x} />)}
              </div>
            </Card>
            <Card title="Financial Goals" action={<Icon name="plus" size={18} style={{ color: 'var(--accent)', cursor: 'pointer' }} stroke={2.2} />}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
                {D.GOALS.slice(0, 3).map((g, i) => <GoalMini key={i} g={g} />)}
              </div>
            </Card>
          </div>
        </main>
      </>
    );
  }

  function Legend({ color, label, val }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
        <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{label}</span>
        <span className="num" style={{ fontSize: 12.5, fontWeight: 600 }}>{val}</span>
      </div>
    );
  }

  Object.assign(window, { Dashboard, DashCard: Card });
})();
