// charts.jsx — animated SVG data-viz for WealthWise.
// All draw/grow on mount. Colors come from props (theme-aware hexes passed in).
(function () {
  const uid = () => 'g' + Math.random().toString(36).slice(2, 8);

  // Catmull-Rom -> cubic bezier smooth path through points [{x,y}]
  function smooth(pts) {
    if (pts.length < 2) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
      const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
      d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
    }
    return d;
  }

  // ---- Cash flow: multiple smooth lines + gradient area fill ----
  function AreaLine({ series, labels, width = 600, height = 240, pad = 28, grid = '#1E2D45', axis = '#4B6180', max: maxOverride }) {
    const id = React.useMemo(uid, []);
    const all = series.flatMap(s => s.data);
    const max = maxOverride || Math.max(...all) * 1.15;
    const W = width, H = height;
    const x = (i, n) => pad + (i * (W - pad * 2)) / (n - 1);
    const y = v => H - pad - (v / max) * (H - pad * 2);
    const rows = 4;
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block', overflow: 'visible' }}>
        <defs>
          {series.map((s, si) => (
            <linearGradient key={si} id={`${id}-${si}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={s.color} stopOpacity="0.28" />
              <stop offset="100%" stopColor={s.color} stopOpacity="0" />
            </linearGradient>
          ))}
        </defs>
        {Array.from({ length: rows + 1 }).map((_, r) => {
          const yy = pad + (r * (H - pad * 2)) / rows;
          return <line key={r} x1={pad} y1={yy} x2={W - pad} y2={yy} stroke={grid} strokeWidth="1" />;
        })}
        {series.map((s, si) => {
          const pts = s.data.map((v, i) => ({ x: x(i, s.data.length), y: y(v) }));
          const line = smooth(pts);
          const area = `${line} L ${pts[pts.length - 1].x} ${H - pad} L ${pts[0].x} ${H - pad} Z`;
          return (
            <g key={si}>
              <path d={area} fill={`url(#${id}-${si})`} style={{ opacity: 0, animation: `ww-fade .9s ease ${.4 + si * .15}s forwards` }} />
              <path d={line} fill="none" stroke={s.color} strokeWidth="2.5" strokeLinecap="round"
                style={{ strokeDasharray: 2000, strokeDashoffset: 2000, animation: `ww-draw 1.4s cubic-bezier(.4,0,.2,1) ${si * .15}s forwards` }} />
              {pts.map((p, i) => (
                <circle key={i} cx={p.x} cy={p.y} r="3" fill={s.color}
                  style={{ opacity: 0, animation: `ww-fade .3s ease ${1 + i * .04}s forwards` }} />
              ))}
            </g>
          );
        })}
        {labels && labels.map((l, i) => (
          <text key={i} x={x(i, labels.length)} y={H - 6} fill={axis} fontSize="11" textAnchor="middle"
            fontFamily="JetBrains Mono, monospace">{l}</text>
        ))}
      </svg>
    );
  }

  // ---- Donut with animated arcs ----
  function Donut({ segments, size = 200, thickness = 26, gap = 0.02, center, centerSub, track = '#1A2236' }) {
    const r = (size - thickness) / 2, C = 2 * Math.PI * r, cx = size / 2;
    let acc = 0;
    const total = segments.reduce((s, x) => s + x.value, 0);
    return (
      <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} style={{ display: 'block' }}>
        <circle cx={cx} cy={cx} r={r} fill="none" stroke={track} strokeWidth={thickness} />
        <g transform={`rotate(-90 ${cx} ${cx})`}>
          {segments.map((s, i) => {
            const frac = s.value / total;
            const len = Math.max(0, (frac - gap) * C);
            const dash = `${len} ${C - len}`;
            const off = -acc * C;
            acc += frac;
            return (
              <circle key={i} cx={cx} cy={cx} r={r} fill="none" stroke={s.color} strokeWidth={thickness}
                strokeLinecap="round"
                strokeDasharray={dash} style={{ strokeDashoffset: C, animation: `ww-arc-${i}-${size} 1s cubic-bezier(.4,0,.2,1) ${.15 + i * .12}s forwards` }} />
            );
          })}
        </g>
        {center && (
          <text x={cx} y={cx - 2} textAnchor="middle" fontFamily="JetBrains Mono, monospace"
            fontSize={size * 0.16} fontWeight="700" fill="var(--text-primary)" style={{ animation: 'ww-fade .6s ease .6s both' }}>{center}</text>
        )}
        {centerSub && (
          <text x={cx} y={cx + size * 0.11} textAnchor="middle" fontFamily="Inter, sans-serif"
            fontSize={size * 0.065} fill="var(--text-secondary)" style={{ animation: 'ww-fade .6s ease .7s both' }}>{centerSub}</text>
        )}
        <style>{segments.map((s, i) => {
          const frac = s.value / total;
          const len = Math.max(0, (frac - gap) * C);
          const off = -segments.slice(0, i).reduce((a, x) => a + x.value / total, 0) * C;
          return `@keyframes ww-arc-${i}-${size}{to{stroke-dashoffset:${off}}}`;
        }).join('')}</style>
      </svg>
    );
  }

  // ---- Circular progress ring ----
  function Ring({ pct, size = 96, stroke = 9, color = '#F59E0B', track = '#243049', label, sub, labelColor }) {
    const id = React.useMemo(uid, []);
    const r = (size - stroke) / 2, C = 2 * Math.PI * r, cx = size / 2;
    const off = C * (1 - Math.min(pct, 100) / 100);
    return (
      <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} style={{ display: 'block' }}>
        <circle cx={cx} cy={cx} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={cx} cy={cx} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          transform={`rotate(-90 ${cx} ${cx})`} strokeDasharray={C}
          style={{ strokeDashoffset: C, animation: `${id}-ring 1.1s cubic-bezier(.4,0,.2,1) .2s forwards` }} />
        {label && <text x={cx} y={cx - 1} textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize={size * 0.24} fontWeight="700" fill={labelColor || 'var(--text-primary)'} style={{ animation: 'ww-fade .5s ease .5s both' }}>{label}</text>}
        {sub && <text x={cx} y={cx + size * 0.16} textAnchor="middle" fontFamily="Inter, sans-serif" fontSize={size * 0.1} fill="var(--text-secondary)" style={{ animation: 'ww-fade .5s ease .6s both' }}>{sub}</text>}
        <style>{`@keyframes ${id}-ring{to{stroke-dashoffset:${off}}}`}</style>
      </svg>
    );
  }

  // ---- Grouped bars (income vs expense) ----
  function GroupedBars({ groups, width = 520, height = 230, pad = 30, colors = ['#10B981', '#EF4444'], grid = '#1E2D45', axis = '#4B6180' }) {
    const max = Math.max(...groups.flatMap(g => g.values)) * 1.15;
    const W = width, H = height, n = groups.length;
    const slot = (W - pad * 2) / n, bw = Math.min(16, slot / 4);
    const y = v => H - pad - (v / max) * (H - pad * 2);
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block' }}>
        {Array.from({ length: 5 }).map((_, r) => {
          const yy = pad + (r * (H - pad * 2)) / 4;
          return <line key={r} x1={pad} y1={yy} x2={W - pad} y2={yy} stroke={grid} strokeWidth="1" />;
        })}
        {groups.map((g, i) => {
          const gx = pad + slot * i + slot / 2;
          return (
            <g key={i}>
              {g.values.map((v, j) => {
                const h = (v / max) * (H - pad * 2);
                const bx = gx - bw - 3 + j * (bw + 6);
                return <rect key={j} x={bx} y={H - pad - h} width={bw} height={h} rx={4} fill={colors[j]}
                  style={{ transformOrigin: `${bx}px ${H - pad}px`, transform: 'scaleY(0)', animation: `ww-grow .7s cubic-bezier(.4,0,.2,1) ${.1 + i * .07}s forwards` }} />;
              })}
              <text x={gx} y={H - 8} textAnchor="middle" fill={axis} fontSize="11" fontFamily="JetBrains Mono, monospace">{g.label}</text>
            </g>
          );
        })}
        <style>{`@keyframes ww-grow{to{transform:scaleY(1)}}`}</style>
      </svg>
    );
  }

  // ---- Horizontal bars (category breakdown) ----
  function HBars({ rows, width = 360, barH = 10, gap = 26, labelW = 0 }) {
    const max = Math.max(...rows.map(r => r.value));
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap }}>
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 13 }}>
              <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{r.label}</span>
              <span className="num" style={{ color: 'var(--text-secondary)', fontSize: 12.5 }}>{r.display}</span>
            </div>
            <div style={{ height: barH, borderRadius: 999, background: 'var(--surface-3)', overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${(r.value / max) * 100}%`, borderRadius: 999, background: r.color, transformOrigin: 'left', transform: 'scaleX(0)', animation: `ww-grow-h .8s cubic-bezier(.22,.61,.36,1) ${.1 + i * .08}s forwards` }} />
            </div>
          </div>
        ))}
        <style>{`@keyframes ww-grow-h{to{transform:scaleX(1)}}`}</style>
      </div>
    );
  }

  // ---- Sparkline ----
  function Sparkline({ data, color = '#10B981', width = 120, height = 36, fill = true, strokeW = 2 }) {
    const id = React.useMemo(uid, []);
    const max = Math.max(...data), min = Math.min(...data);
    const rng = max - min || 1;
    const pts = data.map((v, i) => ({ x: (i * width) / (data.length - 1), y: height - 3 - ((v - min) / rng) * (height - 6) }));
    const line = smooth(pts);
    return (
      <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
        <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" /><stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient></defs>
        {fill && <path d={`${line} L ${width} ${height} L 0 ${height} Z`} fill={`url(#${id})`} style={{ opacity: 0, animation: 'ww-fade .8s ease .3s forwards' }} />}
        <path d={line} fill="none" stroke={color} strokeWidth={strokeW} strokeLinecap="round"
          style={{ strokeDasharray: 600, strokeDashoffset: 600, animation: 'ww-draw 1.2s ease forwards' }} />
      </svg>
    );
  }

  // ---- Stepped line (net worth) ----
  function SteppedLine({ data, labels, width = 600, height = 220, pad = 30, color = '#6366F1', grid = '#1E2D45', axis = '#4B6180' }) {
    const id = React.useMemo(uid, []);
    const max = Math.max(...data) * 1.1, min = Math.min(...data) * 0.9;
    const rng = max - min || 1, W = width, H = height;
    const x = i => pad + (i * (W - pad * 2)) / (data.length - 1);
    const y = v => H - pad - ((v - min) / rng) * (H - pad * 2);
    let d = `M ${x(0)} ${y(data[0])}`;
    for (let i = 1; i < data.length; i++) d += ` L ${x(i)} ${y(data[i - 1])} L ${x(i)} ${y(data[i])}`;
    return (
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: 'block' }}>
        <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" /><stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient></defs>
        {Array.from({ length: 5 }).map((_, r) => {
          const yy = pad + (r * (H - pad * 2)) / 4;
          return <line key={r} x1={pad} y1={yy} x2={W - pad} y2={yy} stroke={grid} strokeWidth="1" />;
        })}
        <path d={`${d} L ${x(data.length - 1)} ${H - pad} L ${x(0)} ${H - pad} Z`} fill={`url(#${id})`} style={{ opacity: 0, animation: 'ww-fade 1s ease .5s forwards' }} />
        <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ strokeDasharray: 3000, strokeDashoffset: 3000, animation: 'ww-draw 1.6s ease forwards' }} />
        {labels && labels.map((l, i) => (
          <text key={i} x={x(i)} y={H - 8} fill={axis} fontSize="11" textAnchor="middle" fontFamily="JetBrains Mono, monospace">{l}</text>
        ))}
      </svg>
    );
  }

  Object.assign(window, { AreaLine, Donut, Ring, GroupedBars, HBars, Sparkline, SteppedLine });
})();
